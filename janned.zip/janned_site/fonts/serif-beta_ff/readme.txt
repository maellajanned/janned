README

This is a beta cut of a new font by Christian Robertson from Betatype.com.

Please take a minute to contribute some constructive feedback.

These fonts are provided as is. They probably won't cause any damage, but if they do, we don't take any responsibility.

You may use the fonts anywhere you want as long as you don't redistribute them or try to sell them.